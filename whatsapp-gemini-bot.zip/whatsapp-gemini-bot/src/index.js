import "dotenv/config";
import express from "express";
import qrcode from "qrcode-terminal";
import { Client, LocalAuth } from "whatsapp-web.js";
import { GoogleGenerativeAI } from "@google/generative-ai";

const PORT = Number(process.env.PORT || 3000);
const BOT_NAME = process.env.BOT_NAME || "Gemini WhatsApp Bot";
const MODEL_NAME = process.env.GEMINI_MODEL || "gemini-1.5-flash";
const replyToEveryMessage =
  String(process.env.REPLY_TO_EVERY_MESSAGE || "true").toLowerCase() === "true";

if (!process.env.GEMINI_API_KEY ||
    process.env.GEMINI_API_KEY === "PASTE_YOUR_GEMINI_API_KEY_HERE") {
  console.error("Missing GEMINI_API_KEY. Copy .env.example to .env and add your key.");
  process.exit(1);
}

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
const model = genAI.getGenerativeModel({
  model: MODEL_NAME,
  systemInstruction:
    "You are a helpful, concise WhatsApp assistant. Reply naturally and clearly. " +
    "Do not claim to be human. Keep replies reasonably short unless asked for detail."
});

const app = express();
app.get("/", (_req, res) => res.send(`${BOT_NAME} is running.`));
app.get("/health", (_req, res) => res.json({ ok: true, bot: BOT_NAME }));
app.listen(PORT, "0.0.0.0", () => {
  console.log(`Health server listening on port ${PORT}`);
});

const client = new Client({
  authStrategy: new LocalAuth({ clientId: "gemini-bot" }),
  puppeteer: {
    headless: true,
    args: ["--no-sandbox", "--disable-setuid-sandbox"]
  }
});

client.on("qr", (qr) => {
  console.log("Scan this QR code with WhatsApp > Linked devices:");
  qrcode.generate(qr, { small: true });
});

client.on("authenticated", () => console.log("WhatsApp authenticated."));
client.on("ready", () => console.log(`${BOT_NAME} is ready.`));
client.on("auth_failure", (message) => console.error("Auth failure:", message));
client.on("disconnected", (reason) => console.warn("WhatsApp disconnected:", reason));

const busyChats = new Set();

client.on("message", async (message) => {
  try {
    if (message.fromMe || message.from === "status@broadcast") return;

    const body = (message.body || "").trim();
    if (!body) return;

    const isCommand = body.toLowerCase().startsWith("!ai ");
    if (!replyToEveryMessage && !isCommand) return;

    const prompt = isCommand ? body.slice(4).trim() : body;
    if (!prompt) {
      await message.reply("Usage: !ai your question");
      return;
    }

    if (busyChats.has(message.from)) {
      await message.reply("I'm still answering your previous message. Please wait a moment.");
      return;
    }

    busyChats.add(message.from);
    await message.sendStateTyping();

    const result = await model.generateContent(prompt);
    const reply = result.response.text()?.trim();

    await message.reply(reply || "Sorry, I couldn't generate a reply.");
  } catch (error) {
    console.error("Message handling error:", error);
    await message.reply("Sorry, something went wrong while contacting Gemini.");
  } finally {
    busyChats.delete(message.from);
  }
});

client.initialize();
