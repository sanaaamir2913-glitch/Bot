# WhatsApp Gemini AI Bot

A beginner-friendly Node.js WhatsApp bot using `whatsapp-web.js` and Google's Gemini API.

## Important

This uses WhatsApp Web automation and is not the official WhatsApp Cloud API. Keep usage personal and modest, and follow WhatsApp's terms. For a business/public bot, use the official Cloud API instead.

## Run locally

1. Install Node.js 20+.
2. Copy `.env.example` to `.env`.
3. Add your Gemini API key to `.env`.
4. Run:

```bash
npm install
npm start
```

5. Scan the QR code from WhatsApp:
   WhatsApp > Settings > Linked devices > Link a device

The session is saved in `.wwebjs_auth/`, so you normally do not need to scan every restart.

## Commands

If `REPLY_TO_EVERY_MESSAGE=true`, the bot replies to incoming chats.

If you set it to `false`, use:

```text
!ai Explain quantum computing simply
```

## Deploying

This bot needs a persistent filesystem because the WhatsApp session is stored locally. A cloud service must support:
- a long-running Node.js process
- persistent storage/disk
- Chromium/Puppeteer dependencies
- secure environment variables

A basic free web-service plan may sleep or lose the session. For reliable 24/7 operation, use a paid persistent service or VPS and keep `.wwebjs_auth/` on persistent storage.

Do not commit `.env` or `.wwebjs_auth/` to GitHub.
